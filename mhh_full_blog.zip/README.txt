Mhh Nation — Full Premium Blog (Netlify-ready)
===============================================

Included files:
- index.html, about.html, contact.html, privacy.html, post.html
- styles.css, app.js, sw.js, manifest.json, sitemap.xml
- assets/ (logo, og-image, cover-sample, product-sample, posts.json, affiliates.json)
- README (this file)

Quick deploy to Netlify (recommended):
1. Create a free account at https://netlify.com
2. On Netlify dashboard -> Sites -> New site -> Deploy manually -> Drag & drop the extracted folder.
3. Netlify will host the site and provide a free HTTPS URL. PWA and service worker work on HTTPS only.
4. For Netlify Forms, the contact form has `data-netlify="true"`. After deploy, Netlify will detect the form submissions.

Monetization steps (quick):
- Google AdSense: Create content (10-20 quality posts), update privacy.html, apply for AdSense. After approval, paste AdSense script inside <head> of index.html and replace ad placeholders.
- Affiliate: Edit assets/affiliates.json to include your product links. Add affiliate links inside posts (assets/posts.json or via editor).
- Sponsored posts & digital products: add pages and payment links (Gumroad, PayPal, Razorpay).

Features in this package:
- Editor with image upload (stores base64 in localStorage)
- Export/Import posts JSON
- Client-side RSS export (button)
- Sitemap template (sitemap.xml) — update URLs after deployment
- Netlify Forms-ready contact form
- Admin lock (double-click Netlify Forms button to set password)
- SEO OG tags and sample OG image
- PWA manifest + service worker for offline reading

Need extras? I can:
- Add server-side comments (Disqus) or convert to headless CMS (Netlify CMS)
- Add automated sitemap.xml and rss.xml generation (on deploy with GitHub Actions)
- Customize look, fonts, and colors, or add multi-language UI translations.

Enjoy — upload to Netlify and send me the URL; I'll help configure AdSense & affiliate + improve SEO.
