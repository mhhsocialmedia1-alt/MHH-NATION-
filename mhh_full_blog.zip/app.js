
/* Full blog app.js: posts in localStorage (key: mhh_posts_full)
   Features: editor, markdown, image upload, export/import, RSS, sitemap update, Netlify Forms, admin lock, search, pagination */
const KEY = 'mhh_posts_full';
const PER_PAGE = 6;
function uid(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,6); }
function save(posts){ localStorage.setItem(KEY, JSON.stringify(posts)); }
function load(){ try{ return JSON.parse(localStorage.getItem(KEY)) || []; }catch(e){ return []; } }
function mdToHtml(md){ if(!md) return ''; let out = md.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); out = out.replace(/```([\s\S]*?)```/g, function(m,code){ return '<pre><code>'+code+'</code></pre>'; }); out = out.replace(/^### (.*$)/gim, '<h3>$1</h3>'); out = out.replace(/^## (.*$)/gim, '<h2>$1</h2>'); out = out.replace(/^# (.*$)/gim, '<h1>$1</h1>'); out = out.replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>'); out = out.replace(/\*(.*?)\*/gim, '<em>$1</em>'); out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/gim, '<a href="$2" target="_blank">$1</a>'); out = out.replace(/(^|\n)\s*[-*] (.*)/gim, function(m,p1,li){ return p1 + '<li>'+li+'</li>'; }); out = out.replace(/(<li>.*<\/li>)/gim, '<ul>$1</ul>'); out = out.replace(/^(?!<h|<ul|<pre|<li|<p|<blockquote)(.+)$/gim, '<p>$1</p>'); return out; }
window.mdToHtml = mdToHtml;

// seed sample posts if none
let posts = load();
if(!posts || posts.length===0){
  try{
    posts = JSON.parse(fetch('assets/posts.json').then(r=>r.text()).then(t=>t)) || [];
  }catch(e){
    posts = [];
  }
  if(!posts || posts.length===0){
    posts = [{id:uid(),title:'Welcome to Mhh Nation',lang:'en',category:'General',tags:['welcome'],cover:'',content:'# Hello\nStart writing posts here.',date:new Date().toISOString(),excerpt:'Welcome post.'}];
  }
  save(posts);
}

// DOM refs
const postsEl = document.getElementById('posts');
const searchEl = document.getElementById('search');
const categoryFilter = document.getElementById('categoryFilter');
const categoryList = document.getElementById('categoryList');
const tagCloud = document.getElementById('tagCloud');
const uiLang = document.getElementById('uiLang');
const paginationEl = document.getElementById('pagination');
const affiliateArea = document.getElementById('affiliateArea');
const importFile = document.getElementById('importFile');

let state = {q:'',cat:'',page:1,lang:''};
uiLang.addEventListener('change', ()=>{ state.lang = uiLang.value; state.page=1; render(); });
searchEl.addEventListener('input', (e)=>{ state.q = e.target.value; state.page=1; render(); });
categoryFilter.addEventListener('change', (e)=>{ state.cat = e.target.value; state.page=1; render(); });

// editor modal elements
const editorModal = document.getElementById('editorModal');
const newPostBtn = document.getElementById('newPost');
const closeEditor = document.getElementById('closeEditor');
const postForm = document.getElementById('postForm');
const postTitle = document.getElementById('postTitle');
const postLang = document.getElementById('postLang');
const postCategory = document.getElementById('postCategory');
const postTags = document.getElementById('postTags');
const postCover = document.getElementById('postCover');
const postContent = document.getElementById('postContent');
const savePost = document.getElementById('savePost');
const cancelPost = document.getElementById('cancelPost');

let editing = null;

// open editor
document.getElementById('newPost').addEventListener('click', ()=> openEditor());
closeEditor.addEventListener('click', ()=> { editorModal.classList.add('hidden'); editorModal.setAttribute('aria-hidden','true'); });

function openEditor(post){
  editing = post || null;
  editorModal.classList.remove('hidden'); editorModal.setAttribute('aria-hidden','false');
  if(post){ postTitle.value = post.title || ''; postLang.value = post.lang || 'en'; postCategory.value = post.category || ''; postTags.value = (post.tags||[]).join(','); postContent.value = post.content || ''; } else { postForm.reset(); postLang.value = uiLang.value || 'en'; }
}

// cover to base64
postCover.addEventListener('change', (e)=>{ const f = e.target.files[0]; if(!f) return; const r = new FileReader(); r.onload = ()=> { postCover.dataset.base64 = r.result; }; r.readAsDataURL(f); });

// save post
postForm.addEventListener('submit', (e)=>{ e.preventDefault(); const title = postTitle.value.trim(); if(!title){ alert('Title required'); return; } const obj = { id: editing ? editing.id : uid(), title: title, lang: postLang.value, category: postCategory.value || 'General', tags: postTags.value.split(',').map(t=>t.trim()).filter(Boolean), cover: postCover.dataset.base64 || (editing ? editing.cover : ''), content: postContent.value, date: new Date().toISOString(), excerpt: postContent.value.replace(/<[^>]+>/g,'').slice(0,140) }; if(editing){ posts = posts.map(p=> p.id===editing.id ? obj : p); } else { posts.unshift(obj); } save(posts); editorModal.classList.add('hidden'); render(); });

// export / import / rss / sitemap / netlify forms hook
document.getElementById('exportBtn').addEventListener('click', ()=>{ const data = JSON.stringify(posts, null,2); const blob = new Blob([data], {type:'application/json'}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'mhh_posts_export.json'; a.click(); URL.revokeObjectURL(url); });
document.getElementById('rssBtn').addEventListener('click', ()=>{ const items = posts.map(p=>`<item><title>${p.title}</title><link>${location.origin+location.pathname}post.html?id=${p.id}</link><pubDate>${new Date(p.date).toUTCString()}</pubDate><description><![CDATA[${mdToHtml(p.content)}]]></description></item>`).join('\n'); const rss = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>Mhh Nation</title><link>${location.origin+location.pathname}</link><description>Feed</description>${items}</channel></rss>`; const blob = new Blob([rss], {type:'application/rss+xml'}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'mhh_feed.xml'; a.click(); URL.revokeObjectURL(url); });
document.getElementById('netlifyFormsBtn').addEventListener('click', ()=>{ alert('Netlify Forms are already enabled on contact page. After deploying to Netlify, go to Site settings → Forms to configure.'); });

// import file
document.getElementById('importFile').addEventListener('change', (e)=>{ const f = e.target.files[0]; if(!f) return; const r = new FileReader(); r.onload = ()=>{ try{ const imported = JSON.parse(r.result); if(!Array.isArray(imported)) throw new Error('Invalid'); const existing = new Set(posts.map(p=>p.id)); imported.forEach(it=>{ if(!existing.has(it.id)) posts.push(it); }); save(posts); render(); alert('Imported '+imported.length+' posts'); }catch(err){ alert('Import failed: '+err.message); } }; r.readAsText(f); });

// admin lock
document.getElementById('netlifyFormsBtn').addEventListener('dblclick', ()=>{ const pwd = localStorage.getItem('mhh_admin_pwd'); if(pwd){ if(confirm('Remove admin password?')) localStorage.removeItem('mhh_admin_pwd'); } else { const np = prompt('Set admin password (stored locally)'); if(np) localStorage.setItem('mhh_admin_pwd', np); } });

function requireAdmin(){ const pwd = localStorage.getItem('mhh_admin_pwd'); if(!pwd) return true; const attempt = prompt('Enter admin password'); return attempt === pwd; }

// render posts with simple fuzzy search + pagination
function fuzzy(text, q){ text = (text||'').toLowerCase(); q = (q||'').toLowerCase(); if(!q) return true; let i=0,j=0; while(i<text.length && j<q.length){ if(text[i]===q[j]) j++; i++; } return j===q.length; }

function render(){ const q = state.q || ''; const cat = state.cat || ''; const lang = state.lang || ''; let arr = posts.filter(p=>{ if(cat && p.category!==cat) return false; if(lang && p.lang!==lang) return false; if(!q) return true; return fuzzy(p.title+' '+p.content+' '+(p.tags||[]).join(' '), q); }); arr.sort((a,b)=> new Date(b.date)-new Date(a.date)); const total = arr.length; const pages = Math.max(1, Math.ceil(total / PER_PAGE)); if(state.page>pages) state.page = pages; const start = (state.page-1)*PER_PAGE; const pageItems = arr.slice(start, start+PER_PAGE); postsEl.innerHTML = ''; pageItems.forEach(p=>{ const card = document.createElement('div'); card.className='post-card fade-in'; const thumb = document.createElement('div'); thumb.className='thumb'; if(p.cover) thumb.style.backgroundImage='url('+p.cover+')'; const content = document.createElement('div'); content.className='post-content'; content.innerHTML = `<h3>${p.title}</h3><div class="post-meta">${p.category||''} • ${new Date(p.date).toLocaleString()}</div><p>${(p.excerpt||p.content.replace(/<[^>]+>/g,'').slice(0,140))}</p><div style="margin-top:8px;"><a class="btn" href="post.html?id=${p.id}" target="_blank">Read</a> <button data-id="${p.id}" class="btn ghost editBtn">Edit</button> <button data-id="${p.id}" class="btn danger delBtn">Delete</button></div>`; card.appendChild(thumb); card.appendChild(content); postsEl.appendChild(card); }); // pagination ui paginationEl.innerHTML=''; for(let i=1;i<=pages;i++){ const b = document.createElement('button'); b.textContent = i; if(i===state.page) b.className='btn primary'; b.addEventListener('click', ()=>{ state.page=i; render(); }); paginationEl.appendChild(b); } buildMeta(); }
// build categories and tags
function buildMeta(){ const cats = [...new Set(posts.map(p=>p.category).filter(Boolean))]; categoryFilter.innerHTML='<option value="">All Categories</option>'; categoryList.innerHTML=''; cats.forEach(c=>{ const opt = document.createElement('option'); opt.value=c; opt.textContent=c; categoryFilter.appendChild(opt); const li = document.createElement('li'); li.textContent=c; categoryList.appendChild(li); }); const allTags = posts.flatMap(p=>p.tags||[]); const unique = [...new Set(allTags)]; tagCloud.innerHTML=''; unique.forEach(t=>{ const s = document.createElement('span'); s.className='tag'; s.textContent=t; tagCloud.appendChild(s); }); }
// post actions
postsEl.addEventListener('click', (e)=>{ const id = e.target.getAttribute('data-id'); if(!id) return; const post = posts.find(p=>p.id===id); if(e.target.classList.contains('editBtn')){ openEditor(post); } if(e.target.classList.contains('delBtn')){ if(!requireAdmin()){ alert('Admin required'); return; } if(confirm('Delete this post?')){ posts = posts.filter(p=>p.id!==id); save(posts); render(); } } });
// affiliate area load
fetch('assets/affiliates.json').then(r=>r.json()).then(a=>{ if(a && a.products && a.products.length){ const p = a.products[0]; affiliateArea.innerHTML = `<div class="affiliate-card"><img src="${p.image}" alt="${p.title}" style="width:120px;height:90px;object-fit:cover;border-radius:8px;margin-right:8px;"/><div><h4>${p.title}</h4><p>${p.price}</p><a class="btn" href="${p.url}" target="_blank" rel="noopener">Buy (affiliate)</a></div></div>`; } });
// initial render
render(); // focus search
searchEl.focus();
